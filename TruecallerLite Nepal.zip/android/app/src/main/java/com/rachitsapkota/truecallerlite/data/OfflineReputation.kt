package com.rachitsapkota.truecallerlite.data

import android.content.Context
import org.json.JSONArray

class OfflineReputation(ctx: Context) {
    private val json = ctx.assets.open("offline_reputation.json").use { it.readBytes().toString(Charsets.UTF_8) }
    private val arr = JSONArray(json)

    fun lookup(e164: String): RepLookupRes? {
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getString("e164") == e164) {
                val labels = mutableListOf<String>()
                val la = o.getJSONArray("labels")
                for (j in 0 until la.length()) labels.add(la.getString(j))
                return RepLookupRes(e164, o.getInt("spamScore"), labels, if (o.has("displayName")) o.getString("displayName") else null)
            }
        }
        return null
    }
}
