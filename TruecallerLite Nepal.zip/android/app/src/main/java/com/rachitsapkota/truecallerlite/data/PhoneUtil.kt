package com.rachitsapkota.truecallerlite.data

object PhoneUtil {
    // Simplistic; replace with libphonenumber for production.
    fun e164(raw: String): String = raw.filter { it.isDigit() }
}
