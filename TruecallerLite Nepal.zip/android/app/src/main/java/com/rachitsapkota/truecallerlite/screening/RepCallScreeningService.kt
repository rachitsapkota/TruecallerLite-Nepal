package com.rachitsapkota.truecallerlite.screening

import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import androidx.annotation.RequiresApi
import com.example.truecallerlite.data.DecisionEngine
import kotlinx.coroutines.*

@RequiresApi(Build.VERSION_CODES.Q)
class RepCallScreeningService : CallScreeningService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val engine by lazy { DecisionEngine(this) }

    override fun onScreenCall(call: Call.Details) {
        val handle = call.handle ?: return
        val number = handle.schemeSpecificPart ?: return

        scope.launch {
            val decision = engine.decide(number)
            val builder = CallResponse.Builder()
            when (decision.action) {
                "BLOCK" -> builder.setDisallowCall(true)
                "SILENCE" -> builder.setSilenceCall(true)
                else -> { }
            }
            builder.setSkipCallLog(false)
            builder.setSkipNotification(false)
            respondToCall(call, builder.build())
        }
    }
}
