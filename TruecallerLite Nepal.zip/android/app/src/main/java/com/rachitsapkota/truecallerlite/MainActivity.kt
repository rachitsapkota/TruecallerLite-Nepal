package com.rachitsapkota.truecallerlite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RachitOverlay()
            MaterialTheme {
                Surface {
                    SettingsScreen()
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    var api by remember { mutableStateOf(BuildConfig.API_BASE) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = "TruecallerLite")
        Text(text = "API: $api")
        Text(text = "Grant overlay permission in system settings if you want caller popups.")
        Text(text = "Min SDK 29 (Android 10). For demo, app uses offline reputation if server unreachable.")

        Spacer(Modifier.weight(1f))
        Text(text = "Developed & Designed by Rachit Sapkota", modifier = Modifier.align(Alignment.CenterHorizontally))

    }
}

@Composable
fun RachitOverlay() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Surface(
            shadowElevation = 4.dp,
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.primary
        ) {
            Text("Developed by Rachit Sapkota", color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.padding(8.dp))
        }
    }
}
