package com.rachitsapkota.truecallerlite.data

import android.content.Context
import com.example.truecallerlite.net.Api
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class Decision(val action: String, val spamScore: Int, val display: String? = null, val labels: List<String> = emptyList())

class DecisionEngine(private val ctx: Context) {
    private val api = Api(ctx)
    private val offline = OfflineReputation(ctx)

    suspend fun decide(numberRaw: String): Decision = withContext(Dispatchers.IO) {
        val e164 = PhoneUtil.e164(numberRaw)
        try {
            val res = api.lookup(e164)
            toDecision(res)
        } catch (e: Exception) {
            val local = offline.lookup(e164)
            if (local != null) toDecision(local) else Decision("ALLOW", 0, labels = emptyList())
        }
    }

    private fun toDecision(res: RepLookupRes): Decision {
        val action = when {
            res.spamScore >= 80 -> "BLOCK"
            res.spamScore >= 60 -> "SILENCE"
            else -> "ALLOW"
        }
        return Decision(action, res.spamScore, res.displayName, res.labels)
    }
}
