package com.rachitsapkota.truecallerlite.net

import android.content.Context
import com.example.truecallerlite.BuildConfig
import com.example.truecallerlite.data.RepLookupReq
import com.example.truecallerlite.data.RepLookupRes
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

interface RepApi {
    @POST("/v1/reputation/lookup")
    suspend fun lookup(@Body req: RepLookupReq): RepLookupRes
}

class Api(ctx: Context) {
    private val api = Retrofit.Builder()
        .baseUrl(BuildConfig.API_BASE)
        .addConverterFactory(MoshiConverterFactory.create())
        .build().create(RepApi::class.java)

    suspend fun lookup(e164: String): RepLookupRes = api.lookup(RepLookupReq(e164))
}
