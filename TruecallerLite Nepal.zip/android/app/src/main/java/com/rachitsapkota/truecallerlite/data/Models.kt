package com.rachitsapkota.truecallerlite.data

data class RepLookupReq(val e164: String)
data class RepLookupRes(val e164: String, val spamScore: Int, val labels: List<String>, val displayName: String?)
