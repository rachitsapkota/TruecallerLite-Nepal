import express from 'express'
export const router = express.Router()
const r = router

r.post('/lookup', async (req, res) => {
  const e164 = (req.body?.e164 || '').replace(/\D/g,'')
  const db = req.app.get('db')
  try {
    const q = await db.query('select e164, spam_score, labels from phone_reputation where e164=$1', [e164])
    if (q.rows.length === 0) return res.json({ e164, spamScore: 0, labels: [], displayName: null })
    const row = q.rows[0]
    return res.json({ e164: row.e164, spamScore: row.spam_score, labels: row.labels?.split(',')||[], displayName: null })
  } catch (e) {
    return res.json({ e164, spamScore: 0, labels: [], displayName: null })
  }
})

r.post('/report', async (req, res) => {
  const e164 = (req.body?.e164 || '').replace(/\D/g,'')
  const label = (req.body?.label || 'spam')
  const db = req.app.get('db')
  await db.query('insert into user_report (e164, label) values ($1,$2)', [e164, label])
  const agg = await db.query('select label, count(*) c from user_report where e164=$1 group by label', [e164])
  const weights = { scam: 1.0, spam: 0.8, sales: 0.6, business: 0.2 }
  const total = agg.rows.reduce((s,a)=> s + Number(a.c), 0)
  const score = total === 0 ? 0 : Math.round(100 * agg.rows.reduce((s,a)=> s + (weights[a.label] ?? 0.3) * Number(a.c), 0) / total)
  const labels = agg.rows.map(a=>a.label).join(',')
  await db.query(`insert into phone_reputation(e164, spam_score, labels, sample_size)
                  values ($1,$2,$3,$4)
                  on conflict (e164) do update set spam_score=excluded.spam_score, labels=excluded.labels, sample_size=excluded.sample_size`,
                  [e164, score, labels, total])
  res.json({ ok: true, score })
})

export default r
