import express from 'express'
import { Pool } from 'pg'
import reputation from './reputation.js'

const app = express()
app.use(express.json())

const pool = new Pool({ connectionString: process.env.DATABASE_URL || 'postgres://rep:rep@localhost:5432/rep' })
app.set('db', pool)

app.get('/about', (req,res)=>res.json({ app:'TruecallerLite API', author:'Rachit Sapkota' }))
app.get('/health', (req,res)=>res.json({ ok: true }))
app.use('/v1/reputation', reputation)

const port = process.env.PORT || 8080
app.listen(port, ()=> console.log('API up on', port))
