create table if not exists phone_reputation (
  e164 text primary key,
  spam_score int not null default 0,
  labels text not null default '',
  sample_size int not null default 0,
  last_seen_at timestamp not null default now()
);
create table if not exists user_report (
  id bigserial primary key,
  e164 text not null,
  label text not null,
  created_at timestamp not null default now()
);
