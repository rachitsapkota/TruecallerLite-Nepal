# TruecallerLite API

## Quick start (without Docker)
1. Install Postgres 16 and create DB `rep` with user/pass `rep/rep` (or set `DATABASE_URL`).
2. Run schema:
   ```sh
   psql "$DATABASE_URL" -f src/init.sql
   ```
3. Install deps & start:
   ```sh
   npm i
   npm run start
   ```
4. Test:
   ```sh
   curl -X POST http://localhost:8080/v1/reputation/lookup -H 'content-type: application/json' -d '{"e164":"9779800000000"}'
   ```

## Docker
```sh
docker build -t truecaller-lite-api .
docker run --rm -p 8080:8080 -e DATABASE_URL=postgres://rep:rep@host.docker.internal:5432/rep truecaller-lite-api
```
