# TruecallerLite — Ready-to-Build Package

This package contains:
- **android/** — Android app (Kotlin, minSdk 29) with CallScreeningService and offline fallback.
- **backend/** — Node + Express API with Postgres schema and scoring.

## Build the Android app (Debug APK)
1. Open **android/** in Android Studio (Giraffe+ recommended).
2. Let it **sync Gradle**. If wrapper complains, use *Gradle -> Wrapper -> Upgrade*.
3. Ensure `android/app/build.gradle` has:
   ```gradle
   buildConfigField "String", "API_BASE", "\"http://10.0.2.2:8080\""
   ```
4. Run the app on a real device (Android 10+). For incoming-call screening you must set the app as the **default call screening app** in system settings.
5. Grant overlay permission if you enable the popup (not included by default to keep sample minimal).

> **Note:** We cannot ship a compiled APK here. Build the Debug APK via **Build > Build APK(s)**.

## Run the backend
1. Start Postgres and apply schema:
   ```sh
   psql "postgres://rep:rep@localhost:5432/rep" -f backend/src/init.sql
   ```
2. Start API:
   ```sh
   cd backend
   npm i
   npm run start
   ```
3. API will listen on `http://localhost:8080`. From Android emulator use `http://10.0.2.2:8080`.

## Seed some data
```sh
curl -X POST http://localhost:8080/v1/reputation/report -H 'content-type: application/json' -d '{"e164":"9779800000000", "label":"scam"}'
```

## Offline demo
Even without the server, the app ships an `assets/offline_reputation.json`. Try calling from `9779800000000` to see a **BLOCK** decision.

## Production TODOs
- Replace naive E.164 normalization with libphonenumber.
- Add overlay UI & user reports UI (skeleton included in blueprint).
- Play Store compliance review & disclosures.


---
**Developed & Designed by Rachit Sapkota**
